import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class InitMigration1692878511433 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
