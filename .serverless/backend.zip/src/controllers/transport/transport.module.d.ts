export declare class TransportModule {
}
