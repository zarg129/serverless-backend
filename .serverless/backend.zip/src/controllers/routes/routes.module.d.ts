export declare class RoutesModule {
}
