import { EnvironmentVariablesInterface } from '../config/interfaces/interfaces';
export declare function getEnvVariable(name: keyof EnvironmentVariablesInterface): string;
