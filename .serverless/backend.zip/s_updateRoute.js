
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zarg33',
  applicationName: 'backend',
  appUid: 'TPKnhTvs2JSN3HCYLH',
  orgUid: 'd15d1456-45f5-46b7-b330-6ffd1bf7f88a',
  deploymentUid: 'd43206bc-d564-47b5-8946-45d9ad4232d1',
  serviceName: 'backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'backend-dev-updateRoute', timeout: 6 };

try {
  const userHandler = require('./src/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}